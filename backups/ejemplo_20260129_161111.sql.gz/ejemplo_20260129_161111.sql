-- Backup generado el 2026-01-29 16:11:11
-- Tipo: FULL
-- Tablas: 7
SET FOREIGN_KEY_CHECKS=0;

-- Estructura de la tabla: alembic_version
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: alembic_version
INSERT INTO `alembic_version` (`version_num`) VALUES 
  ('678f1712eb50');
-- Fin de datos para tabla: alembic_version

-- Estructura de la tabla: backups
CREATE TABLE `backups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(500) NOT NULL,
  `size_mb` float DEFAULT NULL,
  `tables_included` text,
  `backup_type` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: backups
INSERT INTO `backups` (`id`, `filename`, `filepath`, `size_mb`, `tables_included`, `backup_type`, `status`, `created_at`) VALUES 
  (1, 'imported_20260129_161058_backup_full_20260122_124943.sql', 'C:\Proyects\Proyect-CrazyLettuces\Api-CrazyLettuces\backups\imported_20260129_161058_backup_full_20260122_124943.sql', 0.01, '["especiales", "ordenes", "users", "alembic_version", "backups", "notificaciones"]', 'full', 'completed', '2026-01-29 22:10:58');
-- Fin de datos para tabla: backups

-- Estructura de la tabla: especiales
CREATE TABLE `especiales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `ingredientes` text NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: especiales
-- Tabla `especiales` está vacía
-- Fin de datos para tabla: especiales

-- Estructura de la tabla: ingredientes
CREATE TABLE `ingredientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: ingredientes
INSERT INTO `ingredientes` (`id`, `nombre`, `categoria`, `activo`, `fecha_creacion`, `fecha_actualizacion`) VALUES 
  (1, 'Limon', 'vegetales', 1, '2026-01-29 21:07:20', '2026-01-29 21:16:06');
-- Fin de datos para tabla: ingredientes

-- Estructura de la tabla: notificaciones
CREATE TABLE `notificaciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `mensaje` text NOT NULL,
  `leida` tinyint(1) DEFAULT NULL,
  `datos_adicionales` json DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_leida` datetime DEFAULT NULL,
  `orden_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orden_id` (`orden_id`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: notificaciones
-- Tabla `notificaciones` está vacía
-- Fin de datos para tabla: notificaciones

-- Estructura de la tabla: ordenes
CREATE TABLE `ordenes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_unico` varchar(10) NOT NULL,
  `nombre_usuario` varchar(100) NOT NULL,
  `telefono_usuario` varchar(20) NOT NULL,
  `tipo_pedido` varchar(20) NOT NULL,
  `especial_id` int DEFAULT NULL,
  `ingredientes_personalizados` text,
  `precio` decimal(10,2) NOT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_unico` (`codigo_unico`),
  KEY `especial_id` (`especial_id`),
  CONSTRAINT `ordenes_ibfk_1` FOREIGN KEY (`especial_id`) REFERENCES `especiales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: ordenes
-- Tabla `ordenes` está vacía
-- Fin de datos para tabla: ordenes

-- Estructura de la tabla: users
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `rol` int DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `sexo` varchar(10) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: users
INSERT INTO `users` (`id`, `nombre`, `correo`, `contraseña`, `rol`, `telefono`, `sexo`, `fecha_registro`) VALUES 
  (1, 'Juan Carlos', 'carlos@gmail.com', '$2b$12$tyxPIwe4m3Rykp2c/ffNB.ki8C4IyxR06nX/BzOcKddfizRPU6Tby', 1, '7294030702', 'M', '2026-01-29 21:07:06');
-- Fin de datos para tabla: users

SET FOREIGN_KEY_CHECKS=1;
-- Backup completado el 2026-01-29 16:11:11
