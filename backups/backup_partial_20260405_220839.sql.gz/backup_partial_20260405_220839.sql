-- Backup generado el 2026-04-05 22:08:39
-- Tipo: PARTIAL
-- DB_TYPE: mysql
SET FOREIGN_KEY_CHECKS=0;

-- Estructura de la tabla: suplementos
CREATE TABLE `suplementos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `presentacion` varchar(50) NOT NULL,
  `beneficios` text,
  `modo_uso` text,
  `stock` int DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: suplementos
INSERT INTO `suplementos` (`id`, `nombre`, `descripcion`, `precio`, `categoria`, `presentacion`, `beneficios`, `modo_uso`, `stock`, `activo`, `fecha_creacion`, `fecha_actualizacion`) VALUES 
  (1, 'Whey Protein', 'Proteína de suero de leche de rápida absorción, 24g de proteína por porción', '450.99', 'proteinas', 'polvo', 'Ayuda en la recuperación muscular, aumenta la síntesis de proteínas', 'Mezclar 1 scoop (30g) con 250ml de agua, consumir después del entrenamiento', 50, 1, '2026-03-19 00:38:34', '2026-04-02 03:47:08'),
  (2, 'L-Carnitina Líquida', 'Aminoácido que ayuda en el transporte de grasas para su oxidación', '290.99', 'quemadores', 'polvo', 'Acelera la quema de grasas, mejora el rendimiento, reduce la fatiga', 'Tomar 15ml 30 minutos antes del cardio o entrenamiento', 40, 1, '2026-03-19 00:38:34', '2026-04-02 03:43:10'),
  (3, 'Multivitamínico Completo', 'Fórmula con todas las vitaminas y minerales esenciales', '240.99', 'vitaminas', 'polvo', 'Fortalece el sistema inmune, mejora la energía, cubre deficiencias nutricionales', 'Tomar 1 tableta con el desayuno', 80, 1, '2026-03-19 00:38:34', '2026-04-02 03:46:51'),
  (4, 'Cafeína 200mg', 'Estimulante natural que aumenta el rendimiento y la concentración', '120.90', 'termogenicos', 'capsulas', 'Aumenta energía, mejora enfoque, acelera metabolismo', 'Tomar 1 cápsula 30 minutos antes del entrenamiento', 100, 1, '2026-03-19 00:38:34', '2026-04-02 03:43:30'),
  (5, 'Garcinia Cambogia', 'Suplemento natural que ayuda a controlar el apetito', '260.90', 'control_apetito', 'capsulas', 'Reduce ansiedad por comer, mejora estado de ánimo', 'Tomar 2 cápsulas 30 minutos antes de cada comida', 35, 1, '2026-03-19 00:38:34', '2026-04-02 03:45:59'),
  (6, 'Pre-Entreno Explosivo', 'Fórmula completa para maximizar rendimiento deportivo', '490.99', 'energeticos', 'polvo', 'Aumenta fuerza, mejora resistencia, retrasa fatiga muscular', 'Mezclar 1 scoop con 300ml de agua 30 minutos antes de entrenar', 30, 1, '2026-03-19 00:38:34', '2026-04-02 03:46:22'),
  (7, 'Psyllium Husk', 'Fibra natural que mejora el tránsito intestinal y la digestión', '230.90', 'fibras', 'polvo', 'Mejora digestión, regula intestino, controla colesterol', 'Mezclar 1 cucharada con agua o jugo 2 veces al día', 50, 1, '2026-03-19 00:38:34', '2026-04-02 05:13:40'),
  (8, 'Cardo Mariano', 'Hierba que protege y desintoxica el hígado', '190.90', 'detox', 'capsulas', 'Protege hígado, efecto antioxidante, mejora digestión', 'Tomar 2 cápsulas al día con las comidas', 30, 1, '2026-03-19 00:38:34', '2026-04-02 03:47:26'),
  (9, 'Gomitas Multivitamínicas', 'Deliciosas gomitas con vitaminas esenciales para adultos', '190.90', 'vitaminas', 'gomitas', 'Fáciles de tomar, sabor agradable, aporte vitamínico completo', 'Masticar 2 gomitas al día', 80, 1, '2026-03-19 00:38:34', '2026-04-02 03:45:05');
-- Fin de datos para tabla: suplementos

SET FOREIGN_KEY_CHECKS=1;
