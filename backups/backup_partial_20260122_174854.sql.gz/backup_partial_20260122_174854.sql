-- Backup generado el 2026-01-22 17:48:54
-- Tipo: PARTIAL
-- Tablas: 1
SET FOREIGN_KEY_CHECKS=0;

-- Estructura de la tabla: especiales
CREATE TABLE `especiales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `ingredientes` text NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Datos de la tabla: especiales
INSERT INTO `especiales` (`id`, `nombre`, `ingredientes`, `precio`, `activo`, `fecha_creacion`, `fecha_actualizacion`) VALUES 
  (1, 'Picocito', 'Chile en Polvo, Sal, Limon, Chamoy, Gomita Picante', '50.00', 1, '2026-01-21 20:29:35', '2026-01-21 20:29:35');

================================================================================

SET FOREIGN_KEY_CHECKS=1;
-- Backup completado el 2026-01-22 17:48:54
